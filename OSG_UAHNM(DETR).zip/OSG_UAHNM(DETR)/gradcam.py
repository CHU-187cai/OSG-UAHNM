import torch
import torch.nn.functional as F
import cv2
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from PIL import Image
import torchvision.transforms as T
import argparse

class AttentionVisualizer:
    """直接可视化DETR的注意力图"""
    def __init__(self, model_path, device='cuda'):
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        print(f"Loading model from {model_path}...")
        checkpoint = torch.load(model_path, map_location=self.device)
        
        # 加载完整的DETR模型
        from models.detr import build
        
        # 创建完整的args对象
        class Args:
            def __init__(self):
                # 基础设置
                self.device = device
                self.dataset_file = 'custom'  # 不是coco
                
                # Backbone
                self.backbone = 'resnet101'
                self.dilation = False
                self.position_embedding = 'sine'
                self.lr_backbone = 1e-5
                
                # Transformer
                self.enc_layers = 6
                self.dec_layers = 6
                self.dim_feedforward = 2048
                self.hidden_dim = 256
                self.dropout = 0.1
                self.nheads = 8
                self.num_queries = 100
                self.pre_norm = False
                
                # Loss
                self.aux_loss = True
                self.set_cost_class = 1
                self.set_cost_bbox = 5
                self.set_cost_giou = 2
                self.bbox_loss_coef = 5
                self.giou_loss_coef = 2
                self.eos_coef = 0.1
                
                # Segmentation (不使用)
                self.masks = False
                self.mask_loss_coef = 1
                self.dice_loss_coef = 1
                self.frozen_weights = None
        
        args = Args()
        self.model, _, _ = build(args)
        
        # 加载权重
        if 'model' in checkpoint:
            self.model.load_state_dict(checkpoint['model'], strict=False)
        else:
            self.model.load_state_dict(checkpoint, strict=False)
        
        self.model.to(self.device)
        self.model.eval()
        
        # 注册hook来获取注意力权重
        self.attention_weights = []
        self._register_hooks()
        
        # 图像预处理
        self.transform = T.Compose([
            T.Resize(800),
            T.ToTensor(),
            T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        
        print("✅ Model loaded successfully!")
    
    def _register_hooks(self):
        """注册hook获取decoder的cross-attention"""
        def hook_fn(module, input, output):
            # MultiheadAttention返回(attn_output, attn_weights)
            if isinstance(output, tuple) and len(output) == 2:
                self.attention_weights.append(output[1].detach())
        
        # 获取decoder的cross-attention层
        for layer in self.model.transformer.decoder.layers:
            # cross-attention是multihead_attn
            layer.multihead_attn.register_forward_hook(hook_fn)
    
    def visualize_attention(self, image_path, output_dir, top_k=10):
        """可视化注意力图"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # 读取图像
        img = Image.open(image_path).convert('RGB')
        original_img = np.array(img)
        h_orig, w_orig = original_img.shape[:2]
        
        # 预处理
        img_tensor = self.transform(img).unsqueeze(0).to(self.device)
        
        # 清空之前的注意力权重
        self.attention_weights = []
        
        # 前向传播
        with torch.no_grad():
            outputs = self.model(img_tensor)
        
        # 获取预测结果
        pred_logits = outputs['pred_logits'][0]  # (num_queries, num_classes)
        pred_boxes = outputs['pred_boxes'][0]    # (num_queries, 4)
        
        # 获取landslide类的概率 (class 0)
        probs = F.softmax(pred_logits, -1)[:, 0]
        
        # 获取top_k个query
        top_k = min(top_k, len(probs))
        top_scores, top_indices = torch.topk(probs, top_k)
        
        print(f"\n{'='*60}")
        print(f"Processing: {Path(image_path).name}")
        print(f"Image size: {w_orig}x{h_orig}")
        print(f"Score range: [{probs.min():.4f}, {probs.max():.4f}]")
        print(f"\nTop {top_k} queries:")
        for i, (idx, score) in enumerate(zip(top_indices, top_scores)):
            box = pred_boxes[idx].cpu().numpy()
            print(f"  {i+1}. Query {idx.item():3d}: score={score.item():.4f}, box=[{box[0]:.3f}, {box[1]:.3f}, {box[2]:.3f}, {box[3]:.3f}]")
        print(f"{'='*60}\n")
        
        # 如果有注意力权重
        if len(self.attention_weights) > 0:
            print(f"Captured {len(self.attention_weights)} attention layers")
            
            # 使用最后一层decoder的注意力
            attn = self.attention_weights[-1]  # (batch, num_queries, H*W)
            print(f"Attention shape: {attn.shape}")
            
            attn = attn[0]  # (num_queries, H*W)
            
            # 推断特征图尺寸
            hw = attn.shape[1]
            h = w = int(np.sqrt(hw))
            print(f"Feature map size: {h}x{w}")
            
            # 为每个top query生成注意力图
            for rank, query_idx in enumerate(top_indices):
                score = probs[query_idx].item()
                
                # 获取该query的注意力
                query_attn = attn[query_idx].reshape(h, w).cpu().numpy()
                
                # 归一化
                query_attn = (query_attn - query_attn.min()) / (query_attn.max() - query_attn.min() + 1e-8)
                
                # 调整到原图大小
                attn_resized = cv2.resize(query_attn, (w_orig, h_orig))
                
                # 生成热力图
                heatmap = cv2.applyColorMap(np.uint8(255 * attn_resized), cv2.COLORMAP_JET)
                heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
                
                # 叠加到原图
                superimposed = cv2.addWeighted(original_img, 0.6, heatmap, 0.4, 0)
                
                # 添加文字
                text = f'Rank {rank+1} | Query {query_idx.item()} | Score: {score:.4f}'
                cv2.putText(superimposed, text, (10, 40), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 3)
                cv2.putText(superimposed, text, (10, 40), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 2)
                
                # 保存
                img_name = Path(image_path).stem
                save_path = output_dir / f'{img_name}_rank{rank+1:02d}_q{query_idx.item():03d}_s{score:.4f}.jpg'
                plt.imsave(save_path, superimposed)
                
                print(f"  ✅ Saved: {save_path.name}")
        else:
            print("  ⚠️ No attention weights captured!")
            print("  This might be because the model structure is different.")
    
    def process_folder(self, test_folder, output_dir, top_k=10):
        """处理整个文件夹"""
        test_folder = Path(test_folder)
        image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
        image_files = []
        for ext in image_extensions:
            image_files.extend(test_folder.glob(ext))
            image_files.extend(test_folder.glob(ext.upper()))
        
        print(f"\n🔍 Found {len(image_files)} images in {test_folder}\n")
        
        for img_path in sorted(image_files):
            try:
                self.visualize_attention(img_path, output_dir, top_k)
            except Exception as e:
                print(f"❌ Error processing {img_path.name}: {e}")
                import traceback
                traceback.print_exc()

def main():
    parser = argparse.ArgumentParser(description='DETR Attention Visualization')
    parser.add_argument('--model_path', type=str, required=True, help='Path to model checkpoint')
    parser.add_argument('--test_folder', type=str, required=True, help='Path to test images')
    parser.add_argument('--output_dir', type=str, default='./attention_vis', help='Output directory')
    parser.add_argument('--top_k', type=int, default=10, help='Visualize top K queries')
    parser.add_argument('--device', type=str, default='cuda', help='Device')
    
    args = parser.parse_args()
    
    visualizer = AttentionVisualizer(args.model_path, args.device)
    visualizer.process_folder(args.test_folder, args.output_dir, args.top_k)
    
    print("\n" + "="*60)
    print("✅ All done! Check results in:", args.output_dir)
    print("="*60)

if __name__ == '__main__':
    main()
