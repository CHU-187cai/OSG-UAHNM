# osg_uahnm/__init__.py

"""
OSG-UAHNM: Online Sample Generation with Uncertainty-Aware Hard Negative Mining
Plug-and-play module for object detection enhancement.
"""

from .contrastive_loss import ContrastiveLoss
from .module import OSGUAHNMModule

__version__ = "1.0.1"
__author__ = ""
__all__ = ["ContrastiveLoss", "OSGUAHNMModule"]