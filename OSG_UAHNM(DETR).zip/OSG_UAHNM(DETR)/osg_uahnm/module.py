# osg_uahnm/module.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from torchvision.transforms.functional import crop, resize, hflip
import torchvision.transforms.functional as TF
from .contrastive_loss import ContrastiveLoss
from collections import OrderedDict


class SmartFeatureExtractor(nn.Module):
    def __init__(self, backbone):
        super().__init__()
        self.backbone = backbone

    def forward(self, x):
        """
        Args:
            x: tensor (B, C, H, W)
        Returns:
            feat: tensor (B, D) 特征向量
        """
        feats = self.backbone(x)
        
        
        if isinstance(feats, torch.Tensor):
            if feats.dim() == 4:  # (B, C, H, W)
                feats = F.adaptive_avg_pool2d(feats, (1, 1))
            return feats.flatten(1)
        
        
        if isinstance(feats, (dict, OrderedDict)):
            feat_list = []
            for key in sorted(feats.keys()):
                f = feats[key]
                if f.dim() == 4:
                    f = F.adaptive_avg_pool2d(f, (1, 1))
                feat_list.append(f.flatten(1))
            return torch.cat(feat_list, dim=1)
        
        
        if isinstance(feats, (list, tuple)):
            feat_list = []
            for f in feats:
                if f.dim() == 4:
                    f = F.adaptive_avg_pool2d(f, (1, 1))
                feat_list.append(f.flatten(1))
            return torch.cat(feat_list, dim=1)
        
        raise TypeError(f"Unsupported feature type: {type(feats)}")


class OSGUAHNMModule(nn.Module):
    def __init__(self, feature_extractor, contrastive_weight=0.5, margin_base=1.0,
                 alpha=1.0, beta=1.0, crop_size=(256, 256), 
                 conf_thres=0.3, iou_thres=0.5,
                 enable_uahnm=False, uahnm_warmup_epochs=10, uahnm_weight=0.05):
        super().__init__()
        self.feature_extractor = SmartFeatureExtractor(feature_extractor)
        self.contrastive_weight = contrastive_weight
        self.margin_base = margin_base
        self.alpha = alpha
        self.beta = beta
        self.crop_size = crop_size
        self.contrastive_loss = ContrastiveLoss(margin=margin_base)
        
        # UAHNM 配置
        self.enable_hard_mining = enable_uahnm
        self.uahnm_warmup_epochs = uahnm_warmup_epochs
        self.uahnm_weight = uahnm_weight
        self.conf_thres = conf_thres
        self.iou_thres = iou_thres
        
        # 统计信息
        self.register_buffer("_total_hard_negatives", torch.tensor(0, dtype=torch.long))
        self.register_buffer("_forward_count", torch.tensor(0, dtype=torch.long))
        self.register_buffer("current_epoch", torch.tensor(0, dtype=torch.long))

    def _apply_aug(self, img):
        
        if torch.rand(1) < 0.5:
            return TF.hflip(img)
        return img

    def _crop_and_resize(self, img, box):
        
        # 确保 box 坐标有效
        h_img, w_img = img.shape[-2:]
        x1, y1, x2, y2 = box
        x1 = max(0, min(int(x1), w_img - 1))
        y1 = max(0, min(int(y1), h_img - 1))
        x2 = max(x1 + 1, min(int(x2), w_img))
        y2 = max(y1 + 1, min(int(y2), h_img))
        
        h = y2 - y1
        w = x2 - x1
        
        cropped = crop(img, y1, x1, h, w)
        return resize(cropped, self.crop_size, antialias=True)

    def _generate_random_background_box(self, img_shape, boxes, min_size=50):
        
        h, w = img_shape
        for _ in range(50):
            x1 = torch.randint(0, max(1, w - min_size), ()).item()
            y1 = torch.randint(0, max(1, h - min_size), ()).item()
            x2 = min(x1 + min_size + torch.randint(0, 100, ()).item(), w)
            y2 = min(y1 + min_size + torch.randint(0, 100, ()).item(), h)
            candidate = torch.tensor([x1, y1, x2, y2], device=boxes.device, dtype=torch.float32)
            
            if boxes.numel() > 0:
                iou = torchvision.ops.box_iou(candidate.unsqueeze(0), boxes).max()
                if iou < 0.01:
                    return candidate
            else:
                return candidate
        
        
        return torch.tensor([0, 0, w, h], device=boxes.device, dtype=torch.float32)

    def _generate_positive_pairs(self, images, targets):
        
        pos_pairs = []
        for img, tgt in zip(images, targets):
            boxes = tgt['boxes']
            if boxes.numel() == 0:
                continue
            
            try:
                anchor_crop = self._crop_and_resize(img, boxes[0])
                aug1 = self._apply_aug(anchor_crop)
                aug2 = self._apply_aug(anchor_crop)
                
                f1 = self.feature_extractor(aug1.unsqueeze(0))
                f2 = self.feature_extractor(aug2.unsqueeze(0))
                
                lbl = torch.tensor(1.0, device=img.device)
                pos_pairs.append((f1, f2, lbl))
            except Exception as e:
                print(f"⚠️ Error in positive pair generation: {e}")
                continue
                
        return pos_pairs

    def _generate_standard_negative_pairs(self, images, targets):
        
        std_neg_pairs = []
        for img, tgt in zip(images, targets):
            boxes = tgt['boxes']
            if boxes.numel() == 0:
                continue
            
            try:
                bg_box = self._generate_random_background_box(img.shape[-2:], boxes)
                bg_crop = self._crop_and_resize(img, bg_box)
                anchor_crop = self._crop_and_resize(img, boxes[0])
                
                f_anchor = self.feature_extractor(anchor_crop.unsqueeze(0))
                f_bg = self.feature_extractor(bg_crop.unsqueeze(0))
                
                lbl = torch.tensor(0.0, device=img.device)
                std_neg_pairs.append((f_anchor, f_bg, lbl))
            except Exception as e:
                print(f"⚠️ Error in standard negative pair generation: {e}")
                continue
                
        return std_neg_pairs

    def _generate_hard_negative_pairs(self, detector_model, images, targets, current_epoch=0):
       
        
        if not self.enable_hard_mining or current_epoch < self.uahnm_warmup_epochs:
            return []
        
        hard_neg_pairs = []
        original_training = detector_model.training
        detector_model.eval()

        try:
            with torch.no_grad():
                
                from util.misc import NestedTensor
                
                for img, tgt in zip(images, targets):
                    try:
                        
                        if isinstance(img, torch.Tensor):
                            # 创建 mask
                            h, w = img.shape[-2:]
                            mask = torch.zeros((h, w), dtype=torch.bool, device=img.device)
                            nested_img = NestedTensor(img.unsqueeze(0), mask.unsqueeze(0))
                        else:
                            nested_img = img
                        
                       
                        outputs = detector_model(nested_img)
                        
                       
                        pred_logits = outputs['pred_logits'][0]  # (num_queries, num_classes)
                        pred_boxes = outputs['pred_boxes'][0]    # (num_queries, 4)
                        
                        
                        img_h, img_w = img.shape[-2:]
                        pred_boxes_xyxy = self._box_cxcywh_to_xyxy(pred_boxes, img_w, img_h)
                        
                        
                        pred_scores = pred_logits.softmax(-1).max(-1)[0]
                        
                        gt_boxes = tgt['boxes']
                        if gt_boxes.numel() == 0:
                            continue
                        
                        
                        ious = torchvision.ops.box_iou(pred_boxes_xyxy, gt_boxes)
                        max_ious, _ = torch.max(ious, dim=1)
                        
                        
                        conf_mask = (pred_scores > 0.3) & (pred_scores < 0.7)
                        iou_mask = (max_ious > 0.05) & (max_ious < 0.3)
                        candidate_mask = conf_mask & iou_mask
                        
                        candidate_boxes = pred_boxes_xyxy[candidate_mask]
                        candidate_scores = pred_scores[candidate_mask]
                        candidate_ious = max_ious[candidate_mask]
                        
                        if len(candidate_boxes) == 0:
                            continue
                        
                        cls_unc = torch.sigmoid((candidate_scores - 0.5) * 10)
                        loc_unc = torch.sigmoid((0.15 - candidate_ious) * 10)
                        unc_scores = cls_unc * loc_unc
                        
                        k = min(2, len(unc_scores))
                        if k == 0:
                            continue
                        
                        topk_idx = torch.topk(unc_scores, k).indices
                        selected_boxes = candidate_boxes[topk_idx]
                        selected_unc = unc_scores[topk_idx]
                        
                        # 提取特征
                        anchor_crop = self._crop_and_resize(img, gt_boxes[0])
                        anchor_feat = self.feature_extractor(anchor_crop.unsqueeze(0))
                        
                        for hb, unc in zip(selected_boxes, selected_unc):
                            hard_crop = self._crop_and_resize(img, hb)
                            hard_feat = self.feature_extractor(hard_crop.unsqueeze(0))
                            lbl = torch.tensor(0.0, device=img.device)
                            hard_neg_pairs.append((anchor_feat, hard_feat, lbl, unc))
                            
                    except Exception as e:
                        print(f"⚠️ Error in hard negative mining for one image: {e}")
                        continue
                        
        except Exception as e:
            print(f"⚠️ Error in hard negative mining: {e}")
        finally:
            if original_training:
                detector_model.train()
            else:
                detector_model.eval()

        if len(hard_neg_pairs) > 0:
            self._total_hard_negatives += len(hard_neg_pairs)
            
        return hard_neg_pairs

    def _box_cxcywh_to_xyxy(self, boxes, img_w, img_h):
        cx, cy, w, h = boxes.unbind(-1)
        x1 = (cx - w / 2) * img_w
        y1 = (cy - h / 2) * img_h
        x2 = (cx + w / 2) * img_w
        y2 = (cy + h / 2) * img_h
        return torch.stack([x1, y1, x2, y2], dim=-1)

    def _compute_uascl(self, pos_pairs, std_neg_pairs, hard_neg_pairs):
        total_loss = 0.0
        pair_count = 0
        adaptive_margin = self.margin_base

        # 正样本（权重 1.0）
        for f1, f2, lbl in pos_pairs:
            loss, _, _ = self.contrastive_loss(f1, f2, lbl, margin=adaptive_margin)
            total_loss += 1.0 * loss
            pair_count += 1

        # 标准负样本（权重 0.5）
        for f1, f2, lbl in std_neg_pairs:
            loss, _, _ = self.contrastive_loss(f1, f2, lbl, margin=adaptive_margin)
            total_loss += 0.5 * loss
            pair_count += 1

        # 困难负样本（权重 0.1 * unc）
        for f1, f2, lbl, unc in hard_neg_pairs:
            loss, _, _ = self.contrastive_loss(f1, f2, lbl, margin=adaptive_margin)
            weight = self.uahnm_weight * unc.item()
            total_loss += weight * loss
            pair_count += 1

        if pair_count == 0:
            return torch.tensor(0.0, device=pos_pairs[0][0].device if pos_pairs else torch.device('cpu'))
        
        return total_loss / pair_count

    def forward(self, images, targets, detector_model, current_epoch=None):
        """
        Args:
            images: list of tensors (C, H, W)
            targets: list of dicts with 'boxes', 'labels'
            detector_model: DETR model
            current_epoch: current training epoch (optional, will use self.current_epoch if None)
        """
        self._forward_count += 1
        
        if current_epoch is None:
            current_epoch = self.current_epoch.item()
        
        if self.contrastive_weight <= 0:
            return torch.tensor(0.0, device=images[0].device), {}

        try:
            # 生成样本对
            pos_pairs = self._generate_positive_pairs(images, targets)
            std_neg_pairs = self._generate_standard_negative_pairs(images, targets)
            hard_neg_pairs = self._generate_hard_negative_pairs(
                detector_model, images, targets, current_epoch
            )

            # 计算损失
            contrastive_loss = self._compute_uascl(pos_pairs, std_neg_pairs, hard_neg_pairs)
            
            logs = {
                'pos_pairs': len(pos_pairs),
                'std_neg_pairs': len(std_neg_pairs),
                'hard_neg_pairs': len(hard_neg_pairs),
            }

            return self.contrastive_weight * contrastive_loss, logs
            
        except Exception as e:
            print(f"⚠️ OSG-UAHNM forward error: {e}")
            import traceback
            traceback.print_exc()
            return torch.tensor(0.0, device=images[0].device), {}
