# experiments/train_faster_rcnn.py

import os
import sys
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.backbone_utils import resnet_fpn_backbone
from torchvision.models.detection.rpn import AnchorGenerator
from torchvision.ops import MultiScaleRoIAlign
from torchmetrics.detection import MeanAveragePrecision
from tqdm import tqdm
import xml.etree.ElementTree as ET
from PIL import Image
import torchvision.transforms as T
import argparse
import random  
import numpy as np
# ==================== 🆕 随机种子设置 ====================
def set_seed(seed=42):

    #random.seed(seed)
    #np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    #torch.cuda.manual_seed_all(seed)  # 多GPU
    
    #torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True
    
    os.environ['PYTHONHASHSEED'] = str(seed)
    
    print(f"✓ Random seed set to {seed}")

# ==================== OSG-UAHNM 导入 ====================
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from osg_uahnm import OSGUAHNMModule

# ==================== 🔥 核心开关 🔥 ====================
USE_OSG_UAHNM = True  # True = 启用完整版对比学习 | False = 纯净 baseline

# ==================== 配置区 ====================
train_xml_dir   = r'D:\all_datasets\voc_datasets_15\annotations\train'
val_xml_dir     = r'D:\all_datasets\voc_datasets_15\annotations\val'
test_xml_dir    = r'D:\all_datasets\voc_datasets_15\annotations\test'  
train_image_dir = r'D:\all_datasets\voc_datasets_15\images\train'
val_image_dir   = r'D:\all_datasets\voc_datasets_15\images\val'
test_image_dir  = r'D:\all_datasets\voc_datasets_15\images\test' 
RANDOM_SEED = 42
batch_size    = 4
num_epochs    = 50
learning_rate = 1e-4
weight_decay  = 1e-4

# ==================== 🆕 早停配置 ====================
EARLY_STOPPING_PATIENCE = 35  
EARLY_STOPPING_MIN_DELTA = 0.0001 

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
save_dir = "checkpoints"
os.makedirs(save_dir, exist_ok=True)

# ==================== 🆕 早停类 ====================
class EarlyStopping:

    def __init__(self, patience=15, min_delta=0.0001, mode='max', verbose=True):

        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.best_epoch = 0
        
    def __call__(self, current_score, epoch):

        if self.best_score is None:
            
            self.best_score = current_score
            self.best_epoch = epoch
            if self.verbose:
                print(f"[EarlyStopping] Initial best score: {self.best_score:.4f}")
            return True
        
        if self.mode == 'max':
            improved = (current_score - self.best_score) > self.min_delta
        else:  
            improved = (self.best_score - current_score) > self.min_delta
        
        if improved:
            
            if self.verbose:
                print(f"[EarlyStopping] Score improved from {self.best_score:.4f} to {current_score:.4f}")
            self.best_score = current_score
            self.best_epoch = epoch
            self.counter = 0
            return True
        else:
            
            self.counter += 1
            if self.verbose:
                print(f"[EarlyStopping] No improvement for {self.counter}/{self.patience} epochs "
                      f"(best: {self.best_score:.4f} at epoch {self.best_epoch})")
            
            if self.counter >= self.patience:
                self.early_stop = True
                if self.verbose:
                    print(f"\n{'='*60}")
                    print(f"[EarlyStopping] Early stopping triggered!")
                    print(f"Best score: {self.best_score:.4f} at epoch {self.best_epoch}")
                    print(f"{'='*60}\n")
            return False

# ==================== Dataset ====================
class VOCDataset(torch.utils.data.Dataset):
    def __init__(self, xml_dir, image_dir, transforms=None):
        self.xml_files = [os.path.join(xml_dir, f) for f in os.listdir(xml_dir) if f.endswith('.xml')]
        self.image_dir = image_dir
        self.transforms = transforms
        self.classes = ['background', 'landslide']

    def __len__(self):
        return len(self.xml_files)

    def __getitem__(self, idx):
        tree = ET.parse(self.xml_files[idx])
        root = tree.getroot()
        img_name = root.find('filename').text
        img = Image.open(os.path.join(self.image_dir, img_name)).convert('RGB')

        boxes, labels = [], []
        for obj in root.findall('object'):
            bbox = obj.find('bndbox')
            boxes.append([
                float(bbox.find('xmin').text),
                float(bbox.find('ymin').text),
                float(bbox.find('xmax').text),
                float(bbox.find('ymax').text)
            ])
            labels.append(1)

        target = {
            'boxes': torch.tensor(boxes, dtype=torch.float32),
            'labels': torch.tensor(labels, dtype=torch.int64)
        }

        if self.transforms:
            img = self.transforms(img)

        return img, target

# ==================== Transforms ====================
def get_transform(train=True):
    t = [
        T.Resize((640, 640)),
        T.ToTensor(),
        T.Normalize([0.485, 0.456, 0.406],
                    [0.229, 0.224, 0.225])
    ]
    if train:
        t.insert(1, T.RandomHorizontalFlip(0.5))
    return T.Compose(t)

# ==================== Model ====================
def build_model(num_classes=2):
    backbone = resnet_fpn_backbone('resnet101', weights='IMAGENET1K_V1')
    anchor_generator = AnchorGenerator(
        sizes=((32,), (64,), (128,), (256,), (512,)),
        aspect_ratios=((0.5, 1.0, 2.0),) * 5
    )
    roi_pooler = MultiScaleRoIAlign(
        featmap_names=['0', '1', '2', '3'],
        output_size=7,
        sampling_ratio=2
    )
    return FasterRCNN(
        backbone,
        num_classes=num_classes,
        rpn_anchor_generator=anchor_generator,
        box_roi_pool=roi_pooler
    )

# ==================== 🆕 计算 P、R、F1（基于 IoU=0.5）====================
def calculate_pr_f1(all_predictions, all_targets, iou_threshold=0.5, conf_thresholds=None):

    from torchvision.ops import box_iou
    import numpy as np
    
   
    all_pred_boxes = []
    all_gt_boxes = []
    
    for pred, target in zip(all_predictions, all_targets):
        pred_boxes = pred['boxes'].cpu()
        pred_scores = pred['scores'].cpu()
        gt_boxes = target['boxes'].cpu()
        
    
        if 'labels' in pred:
            pred_mask = pred['labels'].cpu() == 1
            pred_boxes = pred_boxes[pred_mask]
            pred_scores = pred_scores[pred_mask]
        
        if 'labels' in target:
            gt_mask = target['labels'].cpu() == 1
            gt_boxes = gt_boxes[gt_mask]
        
        
        for box, score in zip(pred_boxes, pred_scores):
            all_pred_boxes.append({
                'score': score.item(),
                'box': box,
                'image_id': len(all_gt_boxes),  
            })
        
        
        all_gt_boxes.append(gt_boxes)
    
    
    if conf_thresholds is None:
        scores = [p['score'] for p in all_pred_boxes]
        if len(scores) == 0:
            conf_thresholds = [0.5]
        else:
           
            conf_thresholds = np.linspace(0.01, 0.99, 100).tolist()
    
  
    all_pred_boxes.sort(key=lambda x: x['score'], reverse=True)
    
    
    total_gt = sum(len(gt) for gt in all_gt_boxes)
    
    if total_gt == 0:
        print("Warning: No ground truth boxes found!")
        return {
            'best_f1': 0.0,
            'best_precision': 0.0,
            'best_recall': 0.0,
            'best_threshold': 0.5,
            'pr_curve': []
        }
    
   
    pr_curve = []
    best_f1 = 0.0
    best_precision = 0.0
    best_recall = 0.0
    best_threshold = 0.5
    
    for conf_thresh in conf_thresholds:
        
        filtered_preds = [p for p in all_pred_boxes if p['score'] >= conf_thresh]
        
        if len(filtered_preds) == 0:
            continue
        
        gt_matched = [torch.zeros(len(gt), dtype=torch.bool) for gt in all_gt_boxes]
        
        tp = 0
        fp = 0
        
        for pred in filtered_preds:
            image_id = pred['image_id']
            pred_box = pred['box'].unsqueeze(0)
            gt_boxes = all_gt_boxes[image_id]
            
            if len(gt_boxes) == 0:
                fp += 1
                continue
            
            ious = box_iou(pred_box, gt_boxes)[0]
            
         
            max_iou, max_idx = ious.max(dim=0)
            
          
            if max_iou >= iou_threshold and not gt_matched[image_id][max_idx]:
                tp += 1
                gt_matched[image_id][max_idx] = True
            else:
                fp += 1
        
       
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / total_gt if total_gt > 0 else 0.0
        
        
        if precision + recall > 0:
            f1 = 2 * precision * recall / (precision + recall)
        else:
            f1 = 0.0
        
        pr_curve.append({
            'threshold': conf_thresh,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'tp': tp,
            'fp': fp
        })
        
     
        if f1 > best_f1:
            best_f1 = f1
            best_precision = precision
            best_recall = recall
            best_threshold = conf_thresh
    
    return {
        'best_f1': best_f1,
        'best_precision': best_precision,
        'best_recall': best_recall,
        'best_threshold': best_threshold,
        'pr_curve': pr_curve
    }


# ==================== 🆕 评估函数 ====================
def evaluate_model(model, data_loader, device, dataset_name="Validation", save_pr_curve=False, save_dir=None):

    model.eval()
    metric = MeanAveragePrecision(iou_type="bbox").to(device)
    
    print(f"\n{'='*60}")
    print(f"Evaluating on {dataset_name} Set...")
    print(f"{'='*60}")
    
    
    all_predictions = []
    all_targets = []
    
    with torch.no_grad():
        for images, targets in tqdm(data_loader, desc=f"Evaluating {dataset_name}"):
            images = [i.to(device) for i in images]
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
            preds = model(images)
            
            
            metric.update(preds, targets)
            
            
            all_predictions.extend(preds)
            all_targets.extend(targets)
    
    
    map_results = metric.compute()
    map_50_95 = map_results['map'].item()  # mAP@[0.5:0.95]
    map_50 = map_results['map_50'].item()  # mAP@0.5
    
   
    pr_f1_results = calculate_pr_f1(all_predictions, all_targets, iou_threshold=0.5)
    
    precision = pr_f1_results['best_precision']
    recall = pr_f1_results['best_recall']
    f1_score = pr_f1_results['best_f1']
    best_threshold = pr_f1_results['best_threshold']
    
  
    print(f"\n{dataset_name} Set Results:")
    print(f"{'-'*60}")
    print(f"  mAP@[0.5:0.95] : {map_50_95:.4f}")
    print(f"  mAP@0.5        : {map_50:.4f}")
    print(f"  Precision (P)  : {precision:.4f}")
    print(f"  Recall (R)     : {recall:.4f}")
    print(f"  F1 Score       : {f1_score:.4f}")
    print(f"  Best Threshold : {best_threshold:.4f}")
    print(f"{'-'*60}\n")
    

    if save_pr_curve and save_dir is not None:
        import json
        pr_curve_file = os.path.join(save_dir, f"pr_curve_{dataset_name.lower()}.json")
        with open(pr_curve_file, 'w') as f:
            json.dump(pr_f1_results['pr_curve'], f, indent=2)
        print(f"✓ PR curve data saved to: {pr_curve_file}\n")
    
    return {
        'map_50_95': map_50_95,
        'map_50': map_50,
        'precision': precision,
        'recall': recall,
        'f1': f1_score,
        'best_threshold': best_threshold,
        'full_results': map_results,
        'pr_curve': pr_f1_results['pr_curve']
    }

# ==================== 🆕 手动评估函数 ====================
def manual_evaluation(weight_path, eval_set='test'):

    print(f"\n{'='*60}")
    print(f"Manual Evaluation Mode")
    print(f"Weight: {weight_path}")
    print(f"Dataset: {eval_set.upper()}")
    print(f"{'='*60}\n")
    
 
    model = build_model(num_classes=2).to(device)
    
    if not os.path.exists(weight_path):
        raise FileNotFoundError(f"Weight file not found: {weight_path}")
    
    model.load_state_dict(torch.load(weight_path, map_location=device))
    print(f"✓ Model weights loaded from: {weight_path}\n")
    
    
    if eval_set.lower() == 'test':
        xml_dir = test_xml_dir
        image_dir = test_image_dir
        dataset_name = "Test"
    elif eval_set.lower() == 'val':
        xml_dir = val_xml_dir
        image_dir = val_image_dir
        dataset_name = "Validation"
    else:
        raise ValueError(f"Invalid eval_set: {eval_set}. Must be 'test' or 'val'")
    
    
    eval_dataset = VOCDataset(xml_dir, image_dir, get_transform(False))
    eval_loader = DataLoader(
        eval_dataset, 
        batch_size=batch_size,
        shuffle=False, 
        collate_fn=lambda x: tuple(zip(*x))
    )
    
    print(f"Dataset: {len(eval_dataset)} images\n")
    
    
    results = evaluate_model(model, eval_loader, device, dataset_name)
    
  
    result_file = os.path.join(
        save_dir, 
        f"eval_results_{eval_set}_{os.path.basename(weight_path).replace('.pth', '')}.txt"
    )
    with open(result_file, 'w') as f:
        f.write(f"Evaluation Results - {dataset_name} Set\n")
        f.write(f"Weight: {weight_path}\n")
        f.write(f"{'='*60}\n")
        f.write(f"mAP@[0.5:0.95] : {results['map_50_95']:.4f}\n")
        f.write(f"mAP@0.5        : {results['map_50']:.4f}\n")
        f.write(f"Precision      : {results['precision']:.4f}\n")
        f.write(f"Recall         : {results['recall']:.4f}\n")
        f.write(f"F1 Score       : {results['f1']:.4f}\n")
        f.write(f"Best Threshold : {results['best_threshold']:.4f}\n")
    print(f"✓ Results saved to: {result_file}")
    
    return results

# ==================== Main ====================
if __name__ == "__main__":
    set_seed(RANDOM_SEED)
    # ==================== 🆕 命令行参数解析 ====================
    parser = argparse.ArgumentParser(description='Faster R-CNN Training and Evaluation')
    parser.add_argument('--mode', type=str, default='train', 
                        choices=['train', 'eval'],
                        help='Mode: train or eval')
    parser.add_argument('--weight', type=str, default=None,
                        help='Path to weight file for evaluation')
    parser.add_argument('--eval_set', type=str, default='test',
                        choices=['test', 'val'],
                        help='Dataset to evaluate: test or val')
    parser.add_argument('--patience', type=int, default=EARLY_STOPPING_PATIENCE,
                        help='Early stopping patience (default: 15)')
    parser.add_argument('--min_delta', type=float, default=EARLY_STOPPING_MIN_DELTA,
                        help='Early stopping minimum delta (default: 0.0001)')
    parser.add_argument('--seed', type=int, default=RANDOM_SEED,  
                        help='Random seed (default: 42)')
    args = parser.parse_args()
    
    # ==================== 🆕 评估模式 ====================
    if args.mode == 'eval':
        if args.weight is None:
            # 如果没有指定权重，使用默认的 best_model.pth
            args.weight = os.path.join(save_dir, "best_model.pth")
        
        manual_evaluation(args.weight, args.eval_set)
        sys.exit(0)
    
    # ==================== 训练模式 ====================
    train_dataset = VOCDataset(train_xml_dir, train_image_dir, get_transform(True))
    val_dataset   = VOCDataset(val_xml_dir,   val_image_dir,   get_transform(False))

    train_loader = DataLoader(train_dataset, batch_size=batch_size,
                              shuffle=True, collate_fn=lambda x: tuple(zip(*x)))
    val_loader   = DataLoader(val_dataset, batch_size=batch_size,
                              shuffle=False, collate_fn=lambda x: tuple(zip(*x)))

    model = build_model(num_classes=2).to(device)


    osg_uahnm = None
    if USE_OSG_UAHNM:
        osg_uahnm = OSGUAHNMModule(
            feature_extractor=model.backbone,
            contrastive_weight=0.15,  
            margin_base=1.0,
            alpha=1.0,
            beta=1.0,
            crop_size=(128, 128)
        ).to(device)


    params = list(model.parameters())
    if osg_uahnm is not None:
        params += list(osg_uahnm.parameters())

    optimizer = optim.AdamW(params, lr=learning_rate, weight_decay=weight_decay)
    scheduler = CosineAnnealingLR(optimizer, T_max=50)
    scaler = torch.cuda.amp.GradScaler()

    best_map = 0.0
    
    # ==================== 🆕 初始化早停 ====================
    early_stopping = EarlyStopping(
        patience=args.patience,
        min_delta=args.min_delta,
        mode='max',  
        verbose=True
    )
    
    print(f"\n{'='*60}")
    print(f"Training Configuration:")
    print(f"{'-'*60}")
    print(f"  Epochs: {num_epochs}")
    print(f"  Batch Size: {batch_size}")
    print(f"  Learning Rate: {learning_rate}")
    print(f"  Early Stopping Patience: {args.patience}")
    print(f"  Early Stopping Min Delta: {args.min_delta}")
    print(f"  OSG-UAHNM: {'Enabled' if USE_OSG_UAHNM else 'Disabled'}")
    print(f"{'='*60}\n")

    for epoch in range(num_epochs):
        model.train()
        if osg_uahnm is not None:
            osg_uahnm.train()
            
            osg_uahnm.enable_hard_mining = False
            #osg_uahnm.enable_hard_mining = (epoch >= 25)
        
        epoch_loss = 0.0
        for images, targets in tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs}"):
            images = [i.to(device) for i in images]
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

            optimizer.zero_grad()

            with torch.cuda.amp.autocast():
                loss_dict = model(images, targets)
                det_loss = sum(loss_dict.values())

                if osg_uahnm is not None:
                    contr_loss, _ = osg_uahnm(images, targets, detector_model=model)
                    total_loss = det_loss + contr_loss
                else:
                    total_loss = det_loss

            scaler.scale(total_loss).backward()
            scaler.step(optimizer)
            scaler.update()
            
            epoch_loss += total_loss.item()

        scheduler.step()
        avg_loss = epoch_loss / len(train_loader)
        print(f"\nEpoch {epoch+1}/{num_epochs} | Avg Loss: {avg_loss:.4f}")

        # ===== 🆕 使用增强版评估函数 =====
        val_results = evaluate_model(model, val_loader, device, "Validation")
        mAP = val_results['map_50_95']

       
        if mAP > best_map:
            best_map = mAP
            save_path = os.path.join(save_dir, "best_model.pth")
            torch.save(model.state_dict(), save_path)
            print(f">>> Best model saved to: {save_path}")
            print(f">>> Best mAP@[0.5:0.95]: {best_map:.4f}\n")
        
        # ==================== 🆕 早停检查 ====================
        early_stopping(mAP, epoch + 1)
        
        if early_stopping.early_stop:
            print(f"\n{'='*60}")
            print(f"Training stopped early at epoch {epoch+1}")
            print(f"Best mAP@[0.5:0.95]: {best_map:.4f} at epoch {early_stopping.best_epoch}")
            print(f"{'='*60}\n")
            break

    print(f"\n{'='*60}")
    print(f"Training Finished!")
    print(f"Best mAP@[0.5:0.95]: {best_map:.4f}")
    print(f"Total Epochs Trained: {epoch+1}")
    print(f"{'='*60}\n")
