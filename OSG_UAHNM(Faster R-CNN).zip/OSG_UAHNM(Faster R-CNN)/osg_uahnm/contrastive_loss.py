# osg_uahnm/contrastive_loss.py
import torch
import torch.nn as nn
import torch.nn.functional as F
class ContrastiveLoss(nn.Module):
    def __init__(self, margin=1.0):
        super().__init__()
        self.margin = margin

    def forward(self, output1, output2, label, margin=None):
        if output1.shape != output2.shape:
            output2 = F.interpolate(output2, size=output1.shape[2:], mode='bilinear', align_corners=False)

        o1 = output1.view(output1.size(0), -1)
        o2 = output2.view(output2.size(0), -1)

        euclidean_distance_raw = F.pairwise_distance(o1, o2, p=2)

        o1_norm = F.normalize(o1, p=2, dim=1)
        o2_norm = F.normalize(o2, p=2, dim=1)
        euclidean_distance_norm = F.pairwise_distance(o1_norm, o2_norm, p=2)

        m = margin if margin is not None else self.margin

        loss_contrastive = torch.mean(
            label * 0.5 * torch.pow(euclidean_distance_norm, 2) +
            (1 - label) * 0.5 * torch.pow(torch.clamp(m - euclidean_distance_norm, min=0.0), 2)
        )

        return loss_contrastive, euclidean_distance_norm.detach(), euclidean_distance_raw.detach()