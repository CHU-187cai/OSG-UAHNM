# osg_uahnm/module.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from torchvision.transforms.functional import crop, resize, hflip
import torchvision.transforms.functional as TF
from .contrastive_loss import ContrastiveLoss
from collections import OrderedDict


class SmartFeatureExtractor(nn.Module):
    def __init__(self, backbone):
        super().__init__()
        self.backbone = backbone

    def forward(self, x):
        feats = self.backbone(x)
        if isinstance(feats, torch.Tensor):
            return F.adaptive_avg_pool2d(feats, (1, 1)).flatten(1)
        if isinstance(feats, OrderedDict):
            
            feat = feats['3']
            return F.adaptive_avg_pool2d(feat, (1, 1)).flatten(1)
        if isinstance(feats, (list, tuple)):
            feat = feats[3]  
            return F.adaptive_avg_pool2d(feat, (1, 1)).flatten(1)
        raise TypeError(f"Unsupported feature type: {type(feats)}")


class OSGUAHNMModule(nn.Module):
    def __init__(self, feature_extractor, contrastive_weight=0.5, margin_base=1.0,
                 alpha=1.0, beta=1.0, crop_size=(256, 256)):
        super().__init__()
        self.feature_extractor = SmartFeatureExtractor(feature_extractor)
        self.contrastive_weight = contrastive_weight
        self.margin_base = margin_base
        self.alpha = alpha
        self.beta = beta
        self.crop_size = crop_size
        self.contrastive_loss = ContrastiveLoss(margin=margin_base)
        self.enable_hard_mining = True  

    def _apply_aug(self, img):
     
        if torch.rand(1) < 0.5:
            img = TF.hflip(img)
        if torch.rand(1) < 0.5:
            img = TF.adjust_brightness(img, 1.0 + torch.rand(1).item() * 0.4 - 0.2)
        if torch.rand(1) < 0.5:
            img = TF.adjust_contrast(img, 1.0 + torch.rand(1).item() * 0.4 - 0.2)
        return img


    def _crop_and_resize(self, img, box):
        h = max(1, int(box[3] - box[1]))
        w = max(1, int(box[2] - box[0]))
        cropped = crop(img, int(box[1]), int(box[0]), h, w)
        return resize(cropped, self.crop_size, antialias=True)

    def _generate_random_background_box(self, img_shape, boxes, min_size=100):
        h, w = img_shape
        for _ in range(50):
            x1 = torch.randint(0, w - min_size, ()).item()
            y1 = torch.randint(0, h - min_size, ()).item()
            x2 = min(x1 + min_size + torch.randint(0, 200, ()).item(), w)
            y2 = min(y1 + min_size + torch.randint(0, 200, ()).item(), h)
            candidate = torch.tensor([x1, y1, x2, y2], device=boxes.device, dtype=torch.float32)
            if torchvision.ops.box_iou(candidate.unsqueeze(0), boxes).max() < 1e-6:
                return candidate
        return torch.tensor([0, 0, w, h], device=boxes.device, dtype=torch.float32)

    def _generate_positive_pairs(self, images, targets):
        pos_pairs = []
        for img, tgt in zip(images, targets):
            boxes = tgt['boxes']
            if boxes.numel() == 0:
                continue
            anchor_crop = self._crop_and_resize(img, boxes[0])
           
            aug1 = self._apply_aug(anchor_crop)
            aug2 = self._apply_aug(anchor_crop)
            f1 = self.feature_extractor(aug1.unsqueeze(0))
            f2 = self.feature_extractor(aug2.unsqueeze(0))
            lbl = torch.tensor(1.0, device=img.device)
            pos_pairs.append((f1, f2, lbl))
        return pos_pairs

    def _generate_standard_negative_pairs(self, images, targets):
        std_neg_pairs = []
        for img, tgt in zip(images, targets):
            boxes = tgt['boxes']
            if boxes.numel() == 0:
                continue
            bg_box = self._generate_random_background_box(img.shape[-2:], boxes)
            bg_crop = self._crop_and_resize(img, bg_box)
            anchor_crop = self._crop_and_resize(img, boxes[0])
            f_anchor = self.feature_extractor(anchor_crop.unsqueeze(0))
            f_bg = self.feature_extractor(bg_crop.unsqueeze(0))
            lbl = torch.tensor(0.0, device=img.device)
            std_neg_pairs.append((f_anchor, f_bg, lbl))
        return std_neg_pairs

    def _generate_hard_negative_pairs(self, detector_model, images, targets, num_samples=3):
        if not self.enable_hard_mining:  
            return []
     
        hard_neg_pairs = []
        original_training = detector_model.training  
        detector_model.eval()  

        try:
            with torch.no_grad():
                for img, tgt in zip(images, targets):
                   
                    pred = detector_model([img])[0]
                    pred_boxes = pred.get('boxes', torch.empty((0, 4), device=img.device))
                    pred_scores = pred.get('scores', torch.empty((0,), device=img.device))
                    gt_boxes = tgt['boxes']

                    if pred_boxes.numel() == 0 or gt_boxes.numel() == 0:
                        continue

                    ious = torchvision.ops.box_iou(pred_boxes, gt_boxes)
                    max_ious, _ = torch.max(ious, dim=1)

                    # 动态阈值
                    mu_conf = pred_scores.mean() if len(pred_scores) > 0 else torch.tensor(0.5, device=img.device)
                    sigma_conf = pred_scores.std() if len(pred_scores) > 1 else torch.tensor(0.1, device=img.device)
                    mu_iou = max_ious.mean() if len(max_ious) > 0 else torch.tensor(0.5, device=img.device)
                    sigma_iou = max_ious.std() if len(max_ious) > 1 else torch.tensor(0.1, device=img.device)

                    neg_th = torch.clamp(mu_iou - sigma_iou, min=0.3)

                    candidate_mask = (max_ious < neg_th) & (pred_scores > mu_conf)
                    candidate_boxes = pred_boxes[candidate_mask]

                    if len(candidate_boxes) == 0:
                        continue

                    # Uncertainty score
                    cls_unc = (pred_scores[candidate_mask] - mu_conf) / (sigma_conf + 1e-6)
                    loc_unc = (neg_th - max_ious[candidate_mask]) / (sigma_iou + 1e-6)
                    unc_scores = cls_unc * loc_unc

                    if len(unc_scores) == 0:
                        continue

                    mu_unc = unc_scores.mean()
                    sigma_unc = unc_scores.std() if len(unc_scores) > 1 else torch.tensor(0.1, device=img.device)
                    hard_th = mu_unc + sigma_unc

                    hard_mask = unc_scores > hard_th
                    hard_boxes = candidate_boxes[hard_mask]
                    hard_unc = unc_scores[hard_mask]

                    if len(hard_boxes) == 0:
                        continue

                    k = max(1, int(0.3 * len(hard_boxes)))
                    topk_idx = torch.topk(hard_unc, min(k, len(hard_unc))).indices
                    selected_boxes = hard_boxes[topk_idx]
                    selected_unc = hard_unc[topk_idx]

                    anchor_feat = self.feature_extractor(
                        self._crop_and_resize(img, gt_boxes[0]).unsqueeze(0)
                    )

                    for hb, unc in zip(selected_boxes, selected_unc):
                        hard_feat = self.feature_extractor(
                            self._crop_and_resize(img, hb).unsqueeze(0)
                        )
                        lbl = torch.tensor(0.0, device=img.device)
                        hard_neg_pairs.append((anchor_feat, hard_feat, lbl, unc))
        finally:
            
            if original_training:
                detector_model.train()
            else:
                detector_model.eval()

        return hard_neg_pairs


    def _compute_uascl(self, pos_pairs, std_neg_pairs, hard_neg_pairs):
        total_loss = 0.0
        pair_count = 0
        adaptive_margin = self.margin_base

        
        for f1, f2, lbl in pos_pairs:
            loss, _, _ = self.contrastive_loss(f1, f2, lbl, margin=adaptive_margin)
            total_loss += 0.2 * loss  # 权重 1.0
            pair_count += 1

        
        for f1, f2, lbl in std_neg_pairs:
            loss, _, _ = self.contrastive_loss(f1, f2, lbl, margin=adaptive_margin)
            total_loss += 0.1 * loss  # 权重 0.5
            pair_count += 1

        
        for f1, f2, lbl, unc in hard_neg_pairs:
            loss, _, _ = self.contrastive_loss(f1, f2, lbl, margin=adaptive_margin)
            
            unc_normalized = torch.sigmoid(unc - 1.0)  
            total_loss += 0.02 * unc_normalized * loss  
            pair_count += 1

        if pair_count == 0:
            return torch.tensor(0.0, device=pos_pairs[0][0].device if pos_pairs else torch.device('cpu'))
        return total_loss / pair_count


    def forward(self, images, targets, detector_model):
        
        if self.contrastive_weight <= 0:
            return torch.tensor(0.0, device=images[0].device), {}

        pos_pairs = self._generate_positive_pairs(images, targets)
        std_neg_pairs = self._generate_standard_negative_pairs(images, targets)
        hard_neg_pairs = self._generate_hard_negative_pairs(detector_model, images, targets)

        contrastive_loss = self._compute_uascl(pos_pairs, std_neg_pairs, hard_neg_pairs)
        logs = {}  

        return self.contrastive_weight * contrastive_loss, logs